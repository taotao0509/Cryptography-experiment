#include "diffe_hellman.h"
#include "ui_diffe_hellman.h"
#include <QRandomGenerator>
#include <QCryptographicHash>
#include <QDebug>


bool Diffe_Hellman::isPrime(quint64 n, int iterations)
{
    qDebug()<<"iterations = "<<iterations;
    if (n <= 1) return false;
    if (n <= 3) return true;
    if (n % 2 == 0) return false;

    quint64 d = n - 1;
    int s = 0;
    while (d % 2 == 0) {
        d /= 2;
        s++;
    }
    // 生成随机数的生成器
    QRandomGenerator* gen = QRandomGenerator::global();
    for (int i = 0; i < iterations; ++i)
    {
        quint64 a = gen->bounded(2ULL, n - 2);// 生成随机基数 a
        quint64 x = modPow(a, d, n);// 计算 a^d mod n
        if (x == 1 || x == n - 1) continue;// 如果 x是1或n-1

        bool composite = true;// 假设 n 是合数
        for (int j = 0; j < s - 1; ++j)
        {
            x = modPow(x, 2, n);
            if (x == n - 1)
            {
                composite = false;
                break;
            }
        }
        if (composite) return false;// 如果经过 s-1 次后仍是合数，返回 false
    }
    return true;
}
quint64 Diffe_Hellman::generatePrime(int bits)
{
    // 获取全局随机数生成器
    QRandomGenerator* gen = QRandomGenerator::global();

    while (true)
    {
        // 生成一个随机数
        quint64 candidate = gen->generate64() & ((1ULL << bits) - 1);
        qDebug()<<"candidate = "<<candidate;
        // 确保候选数是奇数并且具有正确的位数
        candidate |= (1ULL << (bits - 1)); // 设置最高位
        candidate |= 1; // 设置最低位

        // 检查候选数是否为素数
        if (isPrime(candidate,20))
        {
            return candidate;
        }

    }
}
quint64 Diffe_Hellman::findGenerator(quint64 p)
{

    // 从 2 开始循环，寻找生成元 g，直到小于 p
    for (quint64 g = 2; g < p; ++g) {
        // 检查 g 是否为生成元的条件
        //  modPow(g, (p-1)/2, p) != 1 确保 g 不是平方剩余
        // modPow(g, p-1, p) == 1 确保 g 的阶是 p-1，即 g 是 p 的生成元
        if (modPow(g, (p-1)/2, p) != 1 && modPow(g, p-1, p) == 1)
        {
            return g; // 找到生成元，返回 g
        }
    }
    return 0; // 如果没有找到合适的生成元，返回 0
}

Diffe_Hellman::Diffe_Hellman(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Diffe_Hellman)
{
    ui->setupUi(this);

}

void Diffe_Hellman::on_generateKeysButton_clicked()
{
    // 初始化大素数和生成元
    p = generatePrime(8);
    g = findGenerator( p);  // 选择生成元
    qDebug()<<"g = "<<g;
    ui->resultLabel_key->setText(
        QString("p=%1\ng=%2").arg(p).arg(g)
        );

}
Diffe_Hellman::~Diffe_Hellman()
{
    delete ui;
}

quint64 Diffe_Hellman::modPow(quint64 base, quint64 exponent, quint64 modulus) const {
    quint64 result = 1;
    base = base % modulus;
    while (exponent > 0) {
        if (exponent % 2 == 1) { // 如果 exponent 是奇数
            result = (result * base) % modulus;
        }
        exponent = exponent >> 1; // exponent 除以 2
        base = (base * base) % modulus; // base 自身平方
    }
    return result;
}

QByteArray Diffe_Hellman::deriveSessionKey(quint64 sharedSecret) const
{
    QByteArray secretBytes = QByteArray::number(sharedSecret);
    // 使用 SHA-256 哈希生成会话密钥
    return QCryptographicHash::hash(secretBytes, QCryptographicHash::Sha256);
}

void Diffe_Hellman::on_calculateButton_clicked()
{
    // 生成私钥
    alicePrivateKey = QRandomGenerator::global()->bounded(static_cast<quint64>(1), p);

    bobPrivateKey = QRandomGenerator::global()->bounded(static_cast<quint64>(1), p);

    // 计算公钥

    alicePublicKey = modPow(g, alicePrivateKey, p);
    bobPublicKey = modPow(g, bobPrivateKey, p);
 quint64 x=alicePublicKey;
    quint64 y= bobPublicKey;
    // 计算共享秘密值
    aliceSharedSecret = modPow(bobPublicKey, alicePrivateKey, p);
    bobSharedSecret = modPow(alicePublicKey, bobPrivateKey, p);

    qDebug()<<"aliceSharedSecret = "<<aliceSharedSecret;
    qDebug()<<"bobSharedSecret = "<<bobSharedSecret;

    // 确认共享密钥相同
    if (aliceSharedSecret != bobSharedSecret)
    {
        qDebug() << "Error: Shared secrets do not match!";
        return;
    }

    // 生成会话
    QByteArray sessionKeyAlice = deriveSessionKey(aliceSharedSecret);
    QByteArray sessionKeyBob = deriveSessionKey(bobSharedSecret);

    // 显示结果
    QString strX = QString::number(x);
    QString strY = QString::number(y);
    QString strA = QString::number(aliceSharedSecret);
    QString strB = QString::number(bobSharedSecret);
    ui->resultLabel_key->setText("alicePublicKey: " + strX+"\nbobPublicKey: "+strY);
    ui->resultLabel->setText("aliceSharedSecret = "+strA+
                             "\nbobSharedSecret = "+strB+
                            "\nAlice's Session Key: " + sessionKeyAlice.toHex() +
                             "\nBob's Session Key: " + sessionKeyBob.toHex());
}



