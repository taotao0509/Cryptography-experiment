#ifndef EUCLID_H
#define EUCLID_H

#include <QWidget>

namespace Ui {
class Euclid;
}

class Euclid : public QWidget
{
    Q_OBJECT

public:
    explicit Euclid(QWidget *parent = nullptr);
    ~Euclid();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Euclid *ui;
};

#endif // EUCLID_H
