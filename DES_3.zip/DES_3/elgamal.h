#ifndef ELGAMAL_H
#define ELGAMAL_H

#include <QWidget>
#include <QByteArray>
#include <QString>
#include <QRandomGenerator>
#include <QCryptographicHash>

namespace Ui {
class ElGamal;
}

class ElGamalCore {
public:
    struct PublicKey { quint64 p, g, h; };
    struct PrivateKey { quint64 p, g, x; };

    static void generateKeys(PublicKey& pub, PrivateKey& priv);
    static QByteArray encrypt(const QByteArray& plaintext, PublicKey pub);
    static QByteArray decrypt(const QByteArray& ciphertext, PrivateKey priv);

private:
    static quint64 modPow(quint64 base, quint64 exp, quint64 mod);
    static quint64 modInverse(quint64 a, quint64 mod);
    static bool isPrime(quint64 n, int iterations = 20);
    static quint64 generatePrime(int bits = 16);
    static quint64 findGenerator(quint64 p);
};

class ElGamal : public QWidget {
    Q_OBJECT

public:
    explicit ElGamal(QWidget *parent = nullptr);
    ~ElGamal();

private slots:
    void on_generateKeysButton_clicked();
    void on_encryptButton_clicked();
    void on_decryptButton_clicked();

    void on_decryptButton_2_clicked();

    void on_encryptButton_2_clicked();

private:
    Ui::ElGamal *ui;
    ElGamalCore::PublicKey m_pubKey;
    ElGamalCore::PrivateKey m_privKey;

    void updateKeyDisplay();
};

#endif // ELGAMAL_H
