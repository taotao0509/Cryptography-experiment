#include "euclid.h"
#include "ui_euclid.h"
#include <iostream>
#include <limits>  // 用于处理输入缓冲区清理
#include <QMessageBox>
#include <QTableWidgetItem>
using namespace std;

Euclid::Euclid(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Euclid)
{
    ui->setupUi(this);
    ui->tableWidget->setFixedSize(890, 130);
    ui->tableWidget->resize(ui->tableWidget->sizeHint());
}

Euclid::~Euclid()
{
    delete ui;
}
// 扩展欧几里得算法
//ax + by = gcd(a, b)
int extended_gcd(int a, int b, int &x, int &y)
{
    if (b == 0)
    {
        x = 1;
        y = 0;
        return a;
    }
    int x1, y1;
    int gcd = extended_gcd(b, a % b, x1, y1);
    x = y1;
    y = x1 - (a / b) * y1;
    return gcd;
}

QTableWidgetItem* createValueItem(const QString& text) {
    return new QTableWidgetItem(text);
}

// 求解模逆元
//ax ≡ 1 (mod m)
int mod_inverse(int a, int m)
{
    int x, y;
    int gcd = extended_gcd(a, m, x, y);
    int result=0;
    if (gcd == 1)
    {
        // 确保结果在 [0, m-1] 范围内
        result = (x % m + m) % m;
    }
    else
    {
        // 不存在模逆元
        result = -1;
    }
    return result;
}


void Euclid::on_pushButton_clicked()
{
    QString input_a = ui->lineEdit->text();
    QString input_b = ui->lineEdit_2->text();

    bool convertOk_a, convertOk_b;
    int number_a = input_a.toInt(&convertOk_a);
    int number_b = input_b.toInt(&convertOk_b);

    if (!convertOk_a || !convertOk_b) {
        QMessageBox::warning(this, "错误", "请输入有效的整数！");
        return;
    }

    int s = 0;
    int t = 0;
    int d = extended_gcd(number_a, number_b, s, t);
    qDebug() << "gcd( " << number_a << " , " << number_b << " ) = " << d;

    ui->tableWidget->setRowCount(2); // 设置表格的行数为2
    ui->tableWidget->setColumnCount(2); // 设置表格的列数为2

    QString gcdText = QString("gcd(%1, %2)").arg(number_a).arg(number_b);
    ui->tableWidget->setItem(0, 0, new QTableWidgetItem(gcdText));
    // 将int转换为QString
    ui->tableWidget->setItem(0, 1, new QTableWidgetItem(QString::number(d)));


    int a = number_a;
    int m = number_b;
    int mod_inverse_result = mod_inverse(a, m);

    ui->tableWidget->setItem(1, 0, new QTableWidgetItem(QString("模逆元")));

    if (mod_inverse_result == -1) { // 假设 mod_inverse 返回 -1 表示无逆元
        ui->tableWidget->setItem(1, 1, createValueItem(
                                           QString("%1模%2无逆元").arg(a).arg(m)));
    } else {
        ui->tableWidget->setItem(1, 1, createValueItem(
                                           QString("%1⁻¹ ≡ %2 (mod %3)").arg(a).arg(mod_inverse_result).arg(m)));
    }
}

void Euclid::on_pushButton_2_clicked()
{
    this->close();
}

