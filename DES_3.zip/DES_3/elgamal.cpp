#include "elgamal.h"
#include "ui_elgamal.h"
#include <QDebug>
#include <QMessageBox>

//  ElGamalCore
quint64 ElGamalCore::modPow(quint64 base, quint64 exp, quint64 mod)
{
    quint64 result = 1;
    base = base % mod; // 将基数对模数取模
    while (exp > 0)
    { // 当指数大于0时循环
        if (exp % 2 == 1)
        { // 如果指数是奇数
            result = (result * base) % mod; // 将当前基数乘入结果
        }
        qDebug()<<"exp = "<<exp;
        exp = exp / 2; // 指数除以2
        base = (base * base) % mod; // 基数自乘并取模
    }
    return result;
}

quint64 ElGamalCore::modInverse(quint64 a, quint64 mod)
{
    qint64 old_r = a, r = mod;
    qint64 old_s = 1, s = 0;
    // 执行扩展欧几里得算法
    while (r != 0)
    {
        quint64 quotient = old_r / r;// 计算商
        qint64 temp = r;
        r = old_r - quotient * r;
        old_r = temp;

        temp = s;
        s = old_s - quotient * s;
        old_s = temp;
    }
    // 如果 old_r 最终不等于 1，则 a 没有模逆；否则返回模逆
    return (old_r != 1) ? 0 : (old_s < 0 ? old_s + mod : old_s);
}

bool ElGamalCore::isPrime(quint64 n, int iterations)
{
    qDebug()<<"iterations = "<<iterations;
    if (n <= 1) return false;
    if (n <= 3) return true;
    if (n % 2 == 0) return false;

    quint64 d = n - 1;
    int s = 0;
    while (d % 2 == 0)
    {
        d /= 2;
        s++;
    }
    // 生成随机数的生成器
    QRandomGenerator* gen = QRandomGenerator::global();
    for (int i = 0; i < iterations; ++i)
    {
        quint64 a = gen->bounded(2ULL, n - 2);// 生成随机基数 a
        quint64 x = modPow(a, d, n);// 计算 a^d mod n
        if (x == 1 || x == n - 1) continue;// 如果 x是1或n-1

        bool composite = true;// 假设 n 是合数
        for (int j = 0; j < s - 1; ++j)
        {
            x = modPow(x, 2, n);
            if (x == n - 1)
            {
                composite = false;
                break;
            }
        }
        if (composite) return false;// 如果经过 s-1 次后仍是合数，返回 false
    }
    return true;
}

quint64 ElGamalCore::generatePrime(int bits)
{
    // 获取全局随机数生成器
    QRandomGenerator* gen = QRandomGenerator::global();

    while (true) {
        // 生成一个随机数
        quint64 candidate = gen->generate64() & ((1ULL << bits) - 1);
        qDebug()<<"candidate = "<<candidate;
        // 确保候选数是奇数并且具有正确的位数
        candidate |= (1ULL << (bits - 1)); // 设置最高位
        candidate |= 1; // 设置最低位

        // 检查候选数是否为素数
        if (isPrime(candidate))
        {
            return candidate;
        }

    }
}

quint64 ElGamalCore::findGenerator(quint64 p) {

    // 从 2 开始循环，寻找生成元 g，直到小于 p
    for (quint64 g = 2; g < p; ++g) {
        // 检查 g 是否为生成元的条件
        //  modPow(g, (p-1)/2, p) != 1 确保 g 不是平方剩余
        // modPow(g, p-1, p) == 1 确保 g 的阶是 p-1，即 g 是 p 的生成元
        if (modPow(g, (p-1)/2, p) != 1 && modPow(g, p-1, p) == 1)
        {
            return g; // 找到生成元，返回 g
        }
    }
    return 0; // 如果没有找到合适的生成元，返回 0
}




//key
void ElGamalCore::generateKeys(PublicKey& pub, PrivateKey& priv)
{
    priv.p = generatePrime(8); // 8位素数用于演示
    priv.g = findGenerator(priv.p);
    priv.x = QRandomGenerator::global()->bounded(2ULL, priv.p - 2);// 随机生成 x，范围在 [2, p - 2] 之间，2ULL 表示无符号长长整型的 2
    pub = { priv.p, priv.g, modPow(priv.g, priv.x, priv.p) };// 计算公钥 h = g^x mod p
}




QByteArray ElGamalCore::encrypt(const QByteArray& plaintext, PublicKey pub) {
    QByteArray ciphertext;
    QRandomGenerator* gen = QRandomGenerator::global();

    for (const auto& byte : plaintext) {
        quint64 m = static_cast<quint8>(byte);//无符号 64 位整数
        quint64 k = gen->bounded(2ULL, pub.p - 2);// 随机生成一个整数 k，范围在 [2, p - 2] 之间
        quint64 c1 = modPow(pub.g, k, pub.p);// 计算密文的第一部分 c1 = g^k mod p
        quint64 c2 = (m * modPow(pub.h, k, pub.p)) % pub.p;// 计算密文的第二部分 c2 = m * h^k mod p
        ciphertext.append(reinterpret_cast<char*>(&c1), sizeof(c1));
        ciphertext.append(reinterpret_cast<char*>(&c2), sizeof(c2));
    }
    return ciphertext;
}

QByteArray ElGamalCore::decrypt(const QByteArray& ciphertext, PrivateKey priv) {
    QByteArray plaintext;
    const int blockSize = 2 * sizeof(quint64);

    for (int i = 0; i < ciphertext.size(); i += blockSize) {
        // 从密文中提取 c1
        quint64 c1 = *reinterpret_cast<const quint64*>(ciphertext.constData() + i);
        quint64 c2 = *reinterpret_cast<const quint64*>(ciphertext.constData() + i + sizeof(quint64));
        // 计算 s = c1^x mod p
        quint64 s = modPow(c1, priv.x, priv.p);
        // 计算 s 的模逆元 sInv
        quint64 sInv = modInverse(s, priv.p);
        // 计算明文 m = c2 * sInv mod p
        quint64 m = (c2 * sInv) % priv.p;

        plaintext.append(static_cast<char>(m));
    }
    return plaintext;
}

//  UI
ElGamal::ElGamal(QWidget *parent) : QWidget(parent), ui(new Ui::ElGamal) {
    ui->setupUi(this);
    updateKeyDisplay();
}

ElGamal::~ElGamal() {
    delete ui;
}

void ElGamal::updateKeyDisplay()
{
    ui->publicKeyEdit->setPlainText(
        QString("p=%1\ng=%2\nh=%3").arg(m_pubKey.p).arg(m_pubKey.g).arg(m_pubKey.h)
        );
    ui->privateKeyEdit->setPlainText(
        QString("p=%1\ng=%2\nx=%3").arg(m_privKey.p).arg(m_privKey.g).arg(m_privKey.x)
        );
}

void ElGamal::on_generateKeysButton_clicked() {
    ElGamalCore::generateKeys(m_pubKey, m_privKey);
    updateKeyDisplay();
}

void ElGamal::on_encryptButton_clicked() {
    QByteArray plaintext = ui->plainTextEdit->toPlainText().toUtf8();
    QByteArray ciphertext = ElGamalCore::encrypt(plaintext, m_pubKey);
    ui->cipherTextEdit->setPlainText(ciphertext.toHex().toUpper());
}

void ElGamal::on_decryptButton_clicked() {
    QByteArray ciphertext = QByteArray::fromHex(ui->cipherTextEdit->toPlainText().toLatin1());
    QByteArray plaintext = ElGamalCore::decrypt(ciphertext, m_privKey);
    ui->plainTextEdit->setPlainText(QString::fromUtf8(plaintext));
}

void ElGamal::on_decryptButton_2_clicked()
{
    this->close();
}


void ElGamal::on_encryptButton_2_clicked()
{
    ui->plainTextEdit->clear();
    ui->cipherTextEdit->clear();
}

