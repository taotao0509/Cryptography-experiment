#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{

    DES* Dialog=new DES;
    Dialog->show();
}


void MainWindow::on_pushButton_2_clicked()
{
    AES* Widget=new AES;
    Widget->show();
}


void MainWindow::on_pushButton_3_clicked()
{
    Euclid* Widget=new Euclid;
    Widget->show();

}


void MainWindow::on_pushButton_4_clicked()
{
    this->close();
}


void MainWindow::on_pushButton_5_clicked()
{
    RSA* Window=new RSA;
    Window->show();
}


void MainWindow::on_pushButton_6_clicked()
{
    ElGamal*wid=new ElGamal;
    wid->show();
}


void MainWindow::on_pushButton_7_clicked()
{
    Diffe_Hellman*w =new Diffe_Hellman;
    w->show();
}

