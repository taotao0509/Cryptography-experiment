#include "rsa.h"
#include "ui_rsa.h"
#include <QDebug>
#include <QMessageBox>
#include <QVector>
#include <vector>
#include <cmath>
#include <QRandomGenerator>

quint64 RSA::modPow(quint64 base, quint64 exp, quint64 mod)
{
    quint64 result = 1;
    base = base % mod;
    while (exp > 0)
    {
        if (exp % 2 == 1)
        {
            result = (result * base) % mod;
        }
        exp /= 2;
        base = (base * base) % mod;
    }
    return result;
}

bool RSA::isPrime(quint64 n, int iterations)
{
    if (n <= 1) return false;
    if (n <= 3) return true;
    if (n % 2 == 0) return false;

    quint64 d = n - 1;
    int s = 0;
    while (d % 2 == 0)
    {
        d /= 2;
        s++;
    }
    QRandomGenerator* gen = QRandomGenerator::global();
    for (int i = 0; i < iterations; ++i)
    {
        quint64 a = gen->bounded(2ULL, n - 2);
        quint64 x = modPow(a, d, n);
        if (x == 1 || x == n - 1) continue;
        bool composite = true;
        for (int j = 0; j < s - 1; ++j)
        {
            x = modPow(x, 2, n);
            if (x == n - 1)
            {
                composite = false;
                break;
            }
        }
        if (composite) return false;
    }
    return true;
}

quint64 RSA::generatePrime(int bits)
{
    QRandomGenerator* gen = QRandomGenerator::global();

    while (true) {
        quint64 candidate = gen->generate64() & ((1ULL << bits) - 1);
        candidate |= (1ULL << (bits - 1)); // 确保最高位为1
        candidate |= 1; // 确保奇数

        if (isPrime(candidate, 20))
        {
            return candidate;
        }
    }
}

quint64 RSA::gcd(quint64 a, quint64 b)
{
    while (b != 0) {
        quint64 tmp = b;
        b = a % b;
        a = tmp;
    }
    return a;
}

quint64 RSA::extended_gcd(quint64 a, quint64 b, qint64 &x, qint64 &y)
{
    if (b == 0)
    {
        x = 1;
        y = 0;
        return a;
    }
    qint64 x1, y1;
    quint64 gcd = extended_gcd(b, a % b, x1, y1);
    x = y1;
    y = x1 - (a / b) * y1;
    return gcd;
}

quint64 RSA::mod_inverse(quint64 a, quint64 m)
{
    qint64 x, y;
    quint64 g = extended_gcd(a, m, x, y);
    if (g != 1) return -1;
    return (x % (qint64)m + m) % m;
}

RSA::RSA(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::RSA)
{
    ui->setupUi(this);
}

RSA::~RSA()
{
    delete ui;
}

void RSA::on_decryptButton_2_clicked()
{
    this->close();
}

void RSA::on_generateKeysButton_clicked()
{
    quint64 p = generatePrime(16);
    quint64 q = generatePrime(16);
    quint64 n = p * q;
    quint64 fi = (p - 1) * (q - 1);

    QRandomGenerator* gen = QRandomGenerator::global();
    quint64 e = gen->bounded(2ULL, fi);
    while (gcd(e, fi) != 1)
    {
        e = gen->bounded(2ULL, fi);
    }

    quint64 d = mod_inverse(e, fi);

    QString publicKey = QString("(n = %1, e = %2)").arg(n).arg(e);
    ui->publicKeyEdit->setPlainText(publicKey);

    QString privateKey = QString("(d = %1)").arg(d);
    ui->privateKeyEdit->setPlainText(privateKey);

    this->n = n;
    this->e = e;
    this->d = d;
}

void RSA::on_encryptButton_clicked()
{
    QString plaintext = ui->plainTextEdit->toPlainText();
    std::vector<quint64> ciphertext;

    int blockSize = static_cast<int>(std::floor(std::log2(n) / 8));
    if (blockSize == 0) blockSize = 1;

    for (int i = 0; i < plaintext.length(); i += blockSize)
    {
        quint64 m = 0;
        for (int j = 0; j < blockSize && i + j < plaintext.length(); ++j)
        {
            m = (m << 8) | static_cast<quint64>(plaintext[i + j].unicode());
        }
        quint64 c = modPow(m, e, n);
        ciphertext.push_back(c);
    }

    QString ciphertextStr;
    // 确保每个密文块长度相同（前导补零）
    int blockLength = QString::number(n).length();
    for (size_t i = 0; i < ciphertext.size(); ++i)
    {
        ciphertextStr += QString("%1").arg(ciphertext[i], blockLength, 10, QChar('0'));
    }

    ui->cipherTextEdit->setPlainText(ciphertextStr);
}

void RSA::on_decryptButton_clicked()
{
    QString ciphertextStr = ui->cipherTextEdit->toPlainText();
    std::vector<quint64> ciphertext;

    // 按固定长度分割密文字符串（假设每个密文块长度相同）
    int blockLength = QString::number(n).length(); // 用n的长度估计每个密文块的长度
    for (int i = 0; i < ciphertextStr.length(); i += blockLength)
    {
        QString blockStr = ciphertextStr.mid(i, blockLength);
        if (!blockStr.isEmpty()) {
            ciphertext.push_back(blockStr.toULongLong());
        }
    }

    int blockSize = static_cast<int>(std::floor(std::log2(n) / 8));
    if (blockSize == 0) blockSize = 1;

    QString plaintext;
    for (quint64 c : ciphertext)
    {
        quint64 m = modPow(c, d, n);
        for (int j = blockSize - 1; j >= 0; --j)
        {
            quint64 charCode = (m >> (j * 8)) & 0xFF;
            if (charCode != 0)
            {
                plaintext.append(QChar(static_cast<ushort>(charCode)));
            }
        }
    }

    ui->plainTextEdit->setPlainText(plaintext);
}

void RSA::on_encryptButton_2_clicked()
{
    ui->plainTextEdit->clear();
    ui->cipherTextEdit->clear();
}
