#ifndef DIFFE_HELLMAN_H
#define DIFFE_HELLMAN_H

#include <QWidget>

namespace Ui {
class Diffe_Hellman;
}

class Diffe_Hellman : public QWidget
{
    Q_OBJECT

public:
    explicit Diffe_Hellman(QWidget *parent = nullptr);
    ~Diffe_Hellman();
    bool isPrime(quint64 n, int iterations);
    quint64 findGenerator(quint64 p);
    quint64 generatePrime(int bits);
private slots:
    void on_calculateButton_clicked(); // 按钮点击处理

    void on_generateKeysButton_clicked();

private:
    Ui::Diffe_Hellman *ui;
    quint64 modPow(quint64 base, quint64 exponent, quint64 modulus) const; // 模幂运算
    QByteArray deriveSessionKey(quint64 sharedSecret) const; // 推导会话密钥

    quint64 p;              // 大素数
    quint64 g;              // 生成元
    quint64 alicePrivateKey; // Alice 的私钥
    quint64 bobPrivateKey; // Bob 的私钥
    quint64 alicePublicKey;  // Alice 的公钥
    quint64 bobPublicKey;    // Bob 的公钥
    quint64 aliceSharedSecret; // Alice 和 Bob 共享密钥
    quint64 bobSharedSecret; // Bob 和 Alice 共享密钥
};

#endif // DIFFE_HELLMAN_H
