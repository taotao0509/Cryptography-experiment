#include "aes.h"
#include "ui_aes.h"
#include <QByteArray>
#include <QDebug>
#include <QMessageBox>
#include <QFileDialog>
#include<QPalette>
#include<QTextStream>
#include<iostream>
#include"qaesencryption.h"
using namespace std;
AES::AES(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AES)
{
    ui->setupUi(this);
    QPalette palette;

    this->setPalette(palette);


}

AES::~AES()
{
    delete ui;
}

 QAESEncryption::Aes convertToQAESEncryptionAes(AES::Aes aes)
{
    switch (aes) {
    case AES::AES_128:
        return QAESEncryption::AES_128;
    case AES::AES_192:
        return QAESEncryption::AES_192;
    case AES::AES_256:
        return QAESEncryption::AES_256;
    default:
        return QAESEncryption::AES_128;
    }
}


 AES::Aes AES::getSelectedAesKeyLength()
{

    QString selectedValue = ui->comboBox_keyLen->currentText();
    if (selectedValue == "16") {
        return AES::AES_128;
    } else if (selectedValue == "24") {
        return AES::AES_192;
    } else if (selectedValue == "32") {
        return AES::AES_256;
    }
    // 默认返回 AES_128
    return AES::AES_128;
}


QAESEncryption::Mode convertToQAESMode(int modeIndex)
{
    // 验证QAESEncryption枚举定义
    static_assert(QAESEncryption::ECB == 0, "QAES库枚举顺序与预期不符!");
    static_assert(QAESEncryption::CBC == 1, "QAES库枚举顺序与预期不符!");
    static_assert(QAESEncryption::CFB == 2, "QAES库枚举顺序与预期不符!");

    switch(modeIndex) {
    case 0:  return QAESEncryption::ECB;
    case 1:  return QAESEncryption::CBC;
    case 2:  return QAESEncryption::CFB;
    default:
        qWarning() << "无效模式索引，使用默认ECB";
        return QAESEncryption::ECB;
    }
}

// 加密
QString AES::AES_encryption(const QString &data, const QString &key) {
    QAESEncryption::Aes aesKeyLength = convertToQAESEncryptionAes(getSelectedAesKeyLength());

    QAESEncryption encryption(aesKeyLength, QAESEncryption::ECB, QAESEncryption::PKCS7);


    QByteArray enBA = encryption.encode(data.toUtf8(), key.toUtf8());
    if (enBA.isEmpty()) {
        qDebug() << "Encryption failed!";
        return "";
    }
    qDebug() << "Encryption successful!";
    return QString::fromLatin1(enBA.toBase64());
}
// 解密
QString AES::AES_decryption(const QString &data, const QString &key)
{
    // 获取用户选择的 AES 密钥长度并转换为 QAESEncryption 的枚举类型
    QAESEncryption::Aes aesKeyLength = convertToQAESEncryptionAes(getSelectedAesKeyLength());
    // 创建 QAESEncryption 对象，指定加密模式、填充模式
    QAESEncryption encryption(aesKeyLength, QAESEncryption::ECB, QAESEncryption::PKCS7);
    // 将 Base64 编码的加密数据转换为 QByteArray
    QByteArray enBA = QByteArray::fromBase64(data.toUtf8());
    // 进行解密操作
    QByteArray deBA = encryption.decode(enBA, key.toUtf8());
    if (deBA.isEmpty()) {
        qDebug() << "Decryption failed!";
        return "";
    }
    qDebug() << "Decryption successful!";
    // 移除填充并将解密后的数据转换为 QString
    return QString::fromLatin1(QAESEncryption::RemovePadding(deBA, QAESEncryption::PKCS7));
}

void AES::on_Btn_encrypt_clicked()
{

    QString plaintext=ui->lineEdit_input->text();
    QString key=ui->lineEdit_key->text();

    AES_encryption(plaintext,key);
    qDebug()<<AES_encryption(plaintext,key);
    QString encryptedText = AES_encryption(plaintext, key);
    ui->lineEdit_output->setText(encryptedText);

}


void AES::on_Btn_decrypt_clicked()
{
    // 获取加密后的文本
    QString encryptedText = ui->lineEdit_input->text();
    // 获取密钥
    QString key = ui->lineEdit_key->text();
    // 调用解密函数
    QString decryptedText = AES_decryption(encryptedText, key);
    qDebug()<<AES_decryption(encryptedText, key);
    // 将解密后的文本显示在输入框中
    ui->lineEdit_output->setText(decryptedText);
}






void AES::on_button_back_clicked()
{
    this->close();
}


void AES::on_button_clear_clicked()
{
    ui->lineEdit_input->clear();
    ui->lineEdit_key->clear();
    ui->lineEdit_output->clear();
}

