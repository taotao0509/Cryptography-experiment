#ifndef AES_H
#define AES_H

#include <QWidget>
#include <QDebug>
#include <QByteArray>
#include <QCryptographicHash>
#include <QFile>
#include "qaesencryption.h"
#define MAX_SIZE 192    //buffer size，一定是16,32,48的公倍数
using namespace std;

namespace Ui {
class AES;
}

class AES : public QWidget
{

    Q_OBJECT

public:

    enum Aes {
        AES_128,
        AES_192,
        AES_256
    };

    enum Mode {
        ECB,
        CBC,
        CFB,
        OFB
    };
    explicit AES(QWidget *parent = 0);
    Aes getSelectedAesKeyLength();
    QString AES_decryption(const QString &data, const QString &key);
    QString AES_encryption(const QString &data, const QString &key);

    ~AES();
private slots:






    void on_Btn_decrypt_clicked();



    void on_Btn_encrypt_clicked();

    void on_button_back_clicked();

    void on_button_clear_clicked();

private:
   Ui::AES *ui;


};

#endif // AES_H
