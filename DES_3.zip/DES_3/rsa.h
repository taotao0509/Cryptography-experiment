#ifndef RSA_H
#define RSA_H

#include <QWidget>
#include <QWidget>
#include <QByteArray>
#include <QString>
#include <QRandomGenerator>
#include <QCryptographicHash>
#include <cstdlib>

namespace Ui {
class RSA;
}

class RSA : public QWidget
{
    Q_OBJECT

public:
    explicit RSA(QWidget *parent = nullptr);
    ~RSA();
    quint64 modPow(quint64 base, quint64 exp, quint64 mod);
    quint64 generatePrime(int bits);
    bool isPrime(quint64 n, int iterations);
    quint64 mod_inverse(quint64 a, quint64 m);
    quint64 extended_gcd(quint64 a, quint64 b, qint64 &x, qint64 &y)  ;
    quint64 gcd(quint64 a, quint64 b);
    quint64 n;
    quint64 e;
private slots:
    void on_decryptButton_2_clicked();

    void on_generateKeysButton_clicked();

    void on_encryptButton_clicked();

    void on_decryptButton_clicked();

    void on_encryptButton_2_clicked();

private:
    Ui::RSA *ui;
     quint64 d;
};

#endif // RSA_H
